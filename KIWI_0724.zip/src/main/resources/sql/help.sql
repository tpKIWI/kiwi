-- 도와주세요
ALTER TABLE help
	DROP CONSTRAINT FK_member_TO_help; -- 회원 -> 도와주세요

-- 도와주세요
ALTER TABLE help
	DROP CONSTRAINT PK_help; -- 도와주세요 기본키

-- 도와주세요
DROP TABLE help;

-- 도와주세요
CREATE TABLE help (
	helpidx  NUMBER(5)      NOT NULL, -- 글번호
	title    VARCHAR2(30)   NOT NULL, -- 제목
	contents VARCHAR2(1000) NOT NULL, -- 내용
	wrier    VARCHAR2(50)   NOT NULL, -- 작성자
	hprice   VARCHAR2(20)   NULL,     -- 희망금액
	edate    DATE           NULL,     -- 마감일
	midx     NUMBER(5)      NULL,     -- 회원번호
	htype    VARCHAR2(50)   NULL      -- 분류
);

-- 도와주세요 기본키
CREATE UNIQUE INDEX PK_help
	ON help ( -- 도와주세요
		helpidx ASC -- 글번호
	);

-- 도와주세요
ALTER TABLE help
	ADD
		CONSTRAINT PK_help -- 도와주세요 기본키
		PRIMARY KEY (
			helpidx -- 글번호
		);

-- 도와주세요
ALTER TABLE help
	ADD
		CONSTRAINT FK_member_TO_help -- 회원 -> 도와주세요
		FOREIGN KEY (
			midx -- 회원번호
		)
		REFERENCES member ( -- 회원
			midx -- 회원번호
		);
		
-- 도와주세요 시퀀스
CREATE SEQUENCE help_idx_seq NOCACHE;