package talent.model;

import java.util.List;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

@Repository("talentDAOMyBatis")
public class TalentDAOMyBatis extends SqlSessionDaoSupport implements TalentDAO {

	private final String NS="talent.model.TalentMapper";
	private SqlSession ses;
	
	private static final Logger log
	=LoggerFactory.getLogger(TalentDAOMyBatis.class);
	
	@Resource(name="sqlSessionFactory")
	@Override
	public void setSqlSessionFactory(SqlSessionFactory sqlSessionFactory) {
		super.setSqlSessionFactory(sqlSessionFactory);
	}
	
	public List<CategoryVO> getUpCategory() {
		return this.getSqlSession().selectList(NS+".selectUpCategory");
	}

	public List<CategoryVO> getUpCategory(int upCode){
		return this.getSqlSession().selectList(NS+".selectUpNCategory", upCode);
	}
	
	public List<CategoryVO> getDwCategory(int upcode) {
		return this.getSqlSession().selectList(NS+".selectDwCategory", upcode);
	}

	public List<TalentVO> allTalentList() {
		return this.getSqlSession().selectList(NS+".allTalentLIst");
	}

	public List<CategoryVO> infoByUpCate(int upcode) {
		return getSqlSession().selectList(NS+".infoByUpCate", upcode);
	}
	
	public List<TalentVO> selectByUpCate(int upcode) {
		return getSqlSession().selectList(NS+".selectByUpCate", upcode);
	}

	public List<TalentVO> selectByDwCate(int upcode, int dwcode) {
		return getSqlSession().selectList(NS+".selectByDwCate", dwcode);
	}
	
	public TalentVO selectByTnum(int tnum) {
		return getSqlSession().selectOne(NS+".selectByTnum", tnum);
	}

	public int insertTalent(TalentVO talent) {
		return getSqlSession().insert(NS+".insertTalent", talent);
	}
	
	public int updateTalent(TalentVO talent) {
		return getSqlSession().update(NS+".updateTalent", talent);
	}

	public int deleteTalent(int tnum) {
		return getSqlSession().delete(NS+".deleteTalent", tnum);
	}

	public CategoryVO getUpDwName(int tnum){
		return getSqlSession().selectOne(NS+".getUpDwName", tnum);
	}

	public List<TalentVO> searchTalent(String keyword) {
		return getSqlSession().selectList(NS+".searchTalent", keyword);
	}
	
	/** 후기 관련 ************************************************** */
	public List<ReviewVO> getRvList(int tnum){
		return getSqlSession().selectList(NS+".getRvList", tnum);
	}
	
	public ReviewVO selectByRnum(int rnum){
		return getSqlSession().selectOne(NS+".selectByRnum", rnum);
	}
	
	public List<ReviewVO> allReviewList(){
		return getSqlSession().selectList(NS+".allReviewList");
	}
	
	public int insertReview(ReviewVO review) {
		return getSqlSession().insert(NS+".insertReview", review);
	}

	public int updateReview(ReviewVO review) {
		return getSqlSession().update(NS+".updateReview", review);
	}

	public int deleteReview(int rnum) {
		return getSqlSession().delete(NS+".deleteReview", rnum);
	}
	
	public int getRvCount(int tnum){
		return getSqlSession().selectOne(NS+".getRvCount", tnum);
	}
	
	public int getRscoreAvg(int tnum){
		return getSqlSession().selectOne(NS+".getRscoreAvg", tnum);
	}
	
}
