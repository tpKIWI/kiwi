package help.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import help.model.HelpDAO;
import help.model.HelpVO;
import help.model.PagingVO;

@Service
public class HelpServiceImpl implements HelpService{
	
	@Autowired
	private HelpDAO helpDao;

	public int insertHelp(HelpVO help) {
		System.out.println("HELP======="+help);
		return helpDao.insertHelp(help);
	}
/*
	public List<HelpVO> selectHelpAll(Map<String, Integer> map) {
		return helpDao.selectHelpAll(map);
	}*/

	public List<HelpVO> selectHelpAll(PagingVO paging) {
		return helpDao.selectHelpAll(paging);
	}

	public List<HelpVO> findHelp(PagingVO paging) {
		return helpDao.findHelp(paging);
	}

	public int getTotalCount() {
		return helpDao.getTotalCount();
	}

	public int getTotalCount(PagingVO paging) {
		return helpDao.getTotalCount(paging);
	}

	public HelpVO selectHelpByhidx(Integer helpidx) {
		return helpDao.selectHelpByhidx(helpidx);
	}

	public int deleteHelp(Integer helpidx) {
		return helpDao.deleteHelp(helpidx);
	}
	
	public int updateHelp(HelpVO help){
		return helpDao.updateHelp(help);
	}

	
	

}
