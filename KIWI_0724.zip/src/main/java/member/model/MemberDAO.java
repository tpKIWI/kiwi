package member.model;

public interface MemberDAO {
	
	/**검색이나 로그인시*/
	public MemberVO findMemberByEmail(String email1)
	throws NotMemberException;
	
	/**회원가입*/
	public int insertMember(MemberVO email1);
	
	
	public int emailCheck(String email);
	
	/**로그인 처리*/
	public MemberVO isLoginOK(String email1, String pwd1)
	throws NotMemberException;

	/** 회원정보로 회원번호 가져오기 */
	public MemberVO selectByMidx(int midx);
	
}
