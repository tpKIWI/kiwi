package member.model;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.stereotype.Repository;

@Repository("memberDAOMyBatis")
public class MemberDAOMyBatis extends SqlSessionDaoSupport implements MemberDAO{

	private final String NS = "member.model.MemberMapper";
	private SqlSession ses;
	
	@Resource(name = "sqlSessionFactory")
	@Override
	public void setSqlSessionFactory(SqlSessionFactory sqlSessionFactory) {
		// TODO Auto-generated method stub
		super.setSqlSessionFactory(sqlSessionFactory);
	}


	public int insertMember(MemberVO member) {
		ses=this.getSqlSession();
		int n = ses.insert(NS +".insertMember",member);
		return n;
	}//-----------------------------------------

	public int emailCheck(String email) {
		Integer n = this.getSqlSession().selectOne(NS+".emailCheck",email);
		if(n==null){
			return 1;
		}else{
			return 0;
		}
	}


	public MemberVO isLoginOK(String email1, String pwd1) throws NotMemberException {
		MemberVO member = this.findMemberByEmail(email1);
		if(member==null){
			throw new NotMemberException(email1+"는 존재하지 않습니다.");
		}
		if(!pwd1.equals(member.getPwd())){
			throw new NotMemberException("비밀번호가 틀려요");
		}
		return member;
	}


	public MemberVO findMemberByEmail(String email1) throws NotMemberException {
		ses=getSqlSession();
		MemberVO member = ses.selectOne(NS+".findMemberByEmail",email1);
		return member;
	}

	public MemberVO selectByMidx(int midx){
		ses=this.getSqlSession();
		MemberVO member = ses.selectOne(NS+".selectByMidx", midx);
		
		return member;
	}


}






