package common.service;

import admin.model.AdminVO;
import member.model.NotMemberException;

public interface AdminKiwiService {

	/**검색이나 로그인시*/
	public AdminVO findByAdminEmail(String aemail)
	throws NotMemberException;
	
	
	/**회원가입*/
	
	public int adminEmailCheck(String aemail);
	
	/**로그인 처리*/
	
	
	public AdminVO isAdminLoginOK(String aemail, String apwd)
			throws NotMemberException;


	public AdminVO findAdminByIdx(Integer aidx);


	


	
	
	
}
