package talent.controller;

import org.springframework.stereotype.Controller;

@Controller
public class CategoryController {

	public CategoryController() {

	}

}
