-- 고객센터_F&Q
ALTER TABLE faq
	DROP CONSTRAINT FK_admin_TO_faq; -- 관리자 -> 고객센터_F&Q

-- 고객센터_F&Q
ALTER TABLE faq
	DROP CONSTRAINT PK_faq; -- 고객센터_F&Q 기본키

-- 고객센터_F&Q
DROP TABLE faq;

-- 고객센터_F&Q
CREATE TABLE faq (
	fqidx    NUMBER(5)      NOT NULL, -- 질문번호
	title    VARCAHR2(30)   NULL,     -- 제목
	contents VARCHAR2(1000) NULL,     -- 내용
	aidx     NUMBER(5)      NULL      -- 관리자번호
);

-- 고객센터_F&Q 기본키
CREATE UNIQUE INDEX PK_faq
	ON faq ( -- 고객센터_F&Q
		fqidx ASC -- 질문번호
	);

-- 고객센터_F&Q
ALTER TABLE faq
	ADD
		CONSTRAINT PK_faq -- 고객센터_F&Q 기본키
		PRIMARY KEY (
			fqidx -- 질문번호
		);

-- 고객센터_F&Q
ALTER TABLE faq
	ADD
		CONSTRAINT FK_admin_TO_faq -- 관리자 -> 고객센터_F&Q
		FOREIGN KEY (
			aidx -- 관리자번호
		)
		REFERENCES admin ( -- 관리자
			aidx -- 관리자번호
		);
		
		
DROP SEQUENCE FAQ_FQIDX_SEQ;

CREATE SEQUENCE FAQ_FQIDX_SEQ NOCACHE;		