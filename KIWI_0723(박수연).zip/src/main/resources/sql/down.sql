-- 하위분류
ALTER TABLE down
	DROP CONSTRAINT FK_up_TO_down; -- 상위분류 -> 하위분류

-- 하위분류
ALTER TABLE down
	DROP CONSTRAINT PK_down; -- 하위분류 기본키

-- 하위분류
DROP TABLE down;

-- 하위분류
CREATE TABLE down (
	downcode NUMBER(10)   NOT NULL, -- 하위분류코드
	upcode   NUMBER(10)   NOT NULL, -- 상위분류코드
	downname VARCHAR2(30) NOT NULL  -- 하위분류명
);

-- 하위분류 기본키
CREATE UNIQUE INDEX PK_down
	ON down ( -- 하위분류
		downcode ASC, -- 하위분류코드
		upcode   ASC  -- 상위분류코드
	);

-- 하위분류
ALTER TABLE down
	ADD
		CONSTRAINT PK_down -- 하위분류 기본키
		PRIMARY KEY (
			downcode, -- 하위분류코드
			upcode    -- 상위분류코드
		);

-- 하위분류
ALTER TABLE down
	ADD
		CONSTRAINT FK_up_TO_down -- 상위분류 -> 하위분류
		FOREIGN KEY (
			upcode -- 상위분류코드
		)
		REFERENCES up ( -- 상위분류
			upcode -- 상위분류코드
		);
		
-- 하위분류 시퀀스
DROP SEQUENCE DOWN_UPCODE_SEQ;

CREATE SEQUENCE DOWN_UPCODE_SEQ
START WITH 1
INCREMENT BY 1
NOCACHE;		

DESC DOWN;

-- 1. 디자인 / 2. 광고및미디어 / 3. 컴퓨터 / 4. 번역및작성 / 5. 핸드메이드
-- 1. 디자인
insert into down(downcode, upcode, downname) values(down_upcode_seq.nextval, 1, '로고디자인');
insert into down(downcode, upcode, downname) values(down_upcode_seq.nextval, 1, '배너및상세페이지');
insert into down(downcode, upcode, downname) values(down_upcode_seq.nextval, 1, '포토샵편집');
insert into down(downcode, upcode, downname) values(down_upcode_seq.nextval, 1, '캐리커쳐및인물');
insert into down(downcode, upcode, downname) values(down_upcode_seq.nextval, 1, '3D모델링및도면');
insert into down(downcode, upcode, downname) values(down_upcode_seq.nextval, 1, '기타');

-- 2. 광고및미디어
insert into down(downcode, upcode, downname) values(down_upcode_seq.nextval, 2, '영상제작및편집');
insert into down(downcode, upcode, downname) values(down_upcode_seq.nextval, 2, '스톱모션');
insert into down(downcode, upcode, downname) values(down_upcode_seq.nextval, 2, '애니메이션및3D');
insert into down(downcode, upcode, downname) values(down_upcode_seq.nextval, 2, '음악제작및편집');
insert into down(downcode, upcode, downname) values(down_upcode_seq.nextval, 2, '더빙및녹음');
insert into down(downcode, upcode, downname) values(down_upcode_seq.nextval, 2, '기타');

-- 3. 컴퓨터
insert into down(downcode, upcode, downname) values(down_upcode_seq.nextval, 3, '워드프레스');
insert into down(downcode, upcode, downname) values(down_upcode_seq.nextval, 3, '웹사이트개발');
insert into down(downcode, upcode, downname) values(down_upcode_seq.nextval, 3, '모바일앱및웹');
insert into down(downcode, upcode, downname) values(down_upcode_seq.nextval, 3, '프로그램개발');
insert into down(downcode, upcode, downname) values(down_upcode_seq.nextval, 3, '기술지원');
insert into down(downcode, upcode, downname) values(down_upcode_seq.nextval, 3, '기타');

-- 4. 번역및작성
insert into down(downcode, upcode, downname) values(down_upcode_seq.nextval, 4, '번역및통역');
insert into down(downcode, upcode, downname) values(down_upcode_seq.nextval, 4, '교정및편집');
insert into down(downcode, upcode, downname) values(down_upcode_seq.nextval, 4, '창작및대필');
insert into down(downcode, upcode, downname) values(down_upcode_seq.nextval, 4, '타이핑');
insert into down(downcode, upcode, downname) values(down_upcode_seq.nextval, 4, '이력서및자기소개서');
insert into down(downcode, upcode, downname) values(down_upcode_seq.nextval, 4, '기타');

-- 5. 핸드메이드
insert into down(downcode, upcode, downname) values(down_upcode_seq.nextval, 5, '캔들및방향제');
insert into down(downcode, upcode, downname) values(down_upcode_seq.nextval, 5, '패션');
insert into down(downcode, upcode, downname) values(down_upcode_seq.nextval, 5, '악세사리');
insert into down(downcode, upcode, downname) values(down_upcode_seq.nextval, 5, '문구및팬시');
insert into down(downcode, upcode, downname) values(down_upcode_seq.nextval, 5, '인테리어소품');
insert into down(downcode, upcode, downname) values(down_upcode_seq.nextval, 5, '기타');

select * from down order by downcode asc;
commit;