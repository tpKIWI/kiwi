-- 재능
ALTER TABLE talent
	DROP CONSTRAINT FK_up_TO_talent; -- 상위분류 -> 재능

-- 재능
ALTER TABLE talent
	DROP CONSTRAINT FK_down_TO_talent; -- 하위분류 -> 재능

-- 재능
ALTER TABLE talent
	DROP CONSTRAINT FK_member_TO_talent; -- 회원 -> 재능

-- 재능
ALTER TABLE talent
	DROP CONSTRAINT PK_talent; -- 재능 기본키

-- 재능
DROP TABLE talent;

-- 재능
CREATE TABLE talent (
	tnum      NUMBER(10)     NOT NULL, -- 재능번호
	tname     VARCHAR2(50)   NOT NULL, -- 재능이름
	tprice    NUMBER(10)     NULL,     -- 재능가격
	timg      VARCHAR2(40)   NULL,     -- 재능이미지
	tspec     VARCHAR2(10)   NULL,     -- 스펙
	tcontents VARCHAR2(4000) NULL,     -- 재능설명
	asnrefund VARCHAR2(500)  NULL,     -- AS및환불
	tindate   DATE           NULL,     -- 등록일
	upcode    NUMBER(10)     NOT NULL, -- 상위분류코드
	downcode  NUMBER(10)     NOT NULL, -- 하위분류코드
	midx      NUMBER(5)      NOT NULL  -- 회원번호
);

-- 재능 기본키
CREATE UNIQUE INDEX PK_talent
	ON talent ( -- 재능
		tnum ASC -- 재능번호
	);

-- 재능
ALTER TABLE talent
	ADD
		CONSTRAINT PK_talent -- 재능 기본키
		PRIMARY KEY (
			tnum -- 재능번호
		);

-- 재능
ALTER TABLE talent
	ADD
		CONSTRAINT FK_up_TO_talent -- 상위분류 -> 재능
		FOREIGN KEY (
			upcode -- 상위분류코드
		)
		REFERENCES up ( -- 상위분류
			upcode -- 상위분류코드
		);

-- 재능
ALTER TABLE talent
	ADD
		CONSTRAINT FK_down_TO_talent -- 하위분류 -> 재능
		FOREIGN KEY (
			downcode, -- 하위분류코드
			upcode    -- 상위분류코드
		)
		REFERENCES down ( -- 하위분류
			downcode, -- 하위분류코드
			upcode    -- 상위분류코드
		);

-- 재능
ALTER TABLE talent
	ADD
		CONSTRAINT FK_member_TO_talent -- 회원 -> 재능
		FOREIGN KEY (
			midx -- 회원번호
		)
		REFERENCES member ( -- 회원
			midx -- 회원번호
		);
		
-- 재능 시퀀스
DROP SEQUENCE TALENT_TNUM_SEQ;

CREATE SEQUENCE TALENT_TNUM_SEQ
START WITH 1
INCREMENT BY 1
NOCACHE;		

DESC TALENT;

insert into talent(tnum, tname, tprice, timg, tspec, tcontents, asnrefund, tindate, upcode, downcode, midx)
values(talent_tnum_seq.nextval, '당신이 찾던, 원하는 브랜딩을 디자인 해드립니다.', 50000, 'BrandSkull.jpg', 'HOT', 
'1. 디자인 A (+ 0원) :
브랜드 네임 워드 마크의 경우 캘리 및 워드마크 디자인에 대한 부분이 적용되어 있지 않은 무료 서체 및 제가 구비하고있는 브랜딩 작업 라이센스를 취득한 유료 서체를 적용해 드리는 기본 옵션입니다.
캘리 및 워드마크 디자인이 필요하신 의뢰자 분들께서는 디자인 C 옵션 이상을 선택해주셔야 합니다.

2. 디자인 B (+ 50,000원) : 
브랜드 네임 워드 마크의 경우 캘리 및 워드마크 디자인에 대한 부분이 적용되어 있지 않은 무료 서체 및 제가 구비하고있는 
브랜딩 작업 라이센스를 취득한 유료 서체를 적용해 드리는 기본 옵션입니다.
캘리 및 워드마크 디자인이 필요하신 의뢰자 분들께서는 디자인 C 옵션 이상을 선택해주셔야 합니다.

3. 디자인 C (+ 100,000원) : 
원하시는 스타일 또는 제가 브랜드네임에 맞는 워드마크로 국문 또는 영문 중 선택하신 브랜드명을 바탕으로 기존 일반 서체가 
아닌 직접 디자인한 워드마크를 적용해 드립니다.
* 여러가지 시안을 바탕으로 최종 결과물에 구매자의 의도에 맞게 최고의 퀄리티로 디자인하게 됩니다.

4. 디자인 D 메뉴얼북 (+ 300,000원) : 
원하시는 스타일 또는 제가 브랜드네임에 맞는 워드마크로 국문 또는 영문 중 선택하신 브랜드명을 바탕으로 
기존 일반 서체가 아닌 직접 디자인한 워드마크를 적용해 드립니다.
또한 메뉴얼북은 디자인된 CI를 바탕으로 우편봉투, 명함과 같은 지류에서 부터 관련 상품을 제작하기전 적용사례, 
간판과 같은 사인물과 같은 기본 브랜딩 관련 Mock Up 디자인을 적용할 수 있는 메뉴얼북을 작업해 보내드립니다.'
,
'환불규정: 작업에 대한 판매자에게 책임이 있을 경우 협의 환불해드리며, 시안 배송 후 7일이 지나게 되면 자동으로 완료처리가 됩니다. 
시안을 받으시고 원하시는 수정 및 추가 작업에 대한 부분을 검토 하여 메시지 보내주시기 바랍니다.', sysdate, 1, 1, 1);

commit;
select * from talent;