package notice.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class NoticeController {
	
	@RequestMapping("/service/noticeList.do")
	public void showIndex(){
		
	}
	
	@RequestMapping("/service/noticeInsert.do")
	public void showInsert(){
		
	}
	
	@RequestMapping("/service/noticeView.do")
	public void showView(){
		
	}
	
	@RequestMapping("/service/noticeUpdate.do")
	public void showUpdate(){
		
	}
	
}
