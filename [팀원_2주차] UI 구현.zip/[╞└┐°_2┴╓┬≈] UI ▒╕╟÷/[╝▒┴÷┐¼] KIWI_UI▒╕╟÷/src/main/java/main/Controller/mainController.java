package main.Controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class mainController {

	
	@RequestMapping("/main/main.do")
	public void showIndex(){
		//뷰이름이 반환되지 않으면
		//RequestMapping에 지정된 매핑 url에
		//.do를 빼고 .jsp를 붙여 찾아간다.
		//WEB-INF/view/index.jsp
	}

	
}
