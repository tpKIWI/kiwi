package help.model;

import java.io.Serializable;
import java.sql.Date;
public class HelpVO {
	
	private Integer helpidx;
	private String htype;
	private String title;
	private String contents;
	private String writer;
	private String hprice;
	private java.sql.Date edate;
	private int midx;
	
	
	public HelpVO(){
		
	}


	public HelpVO(Integer helpidx, String htype, String title, String contents, String writer, String hprice,
			Date edate, int midx) {
		super();
		this.helpidx = helpidx;
		this.htype = htype;
		this.title = title;
		this.contents = contents;
		this.writer = writer;
		this.hprice = hprice;
		this.edate = edate;
		this.midx = midx;
	}


	public Integer getHelpidx() {
		return helpidx;
	}


	public void setHelpidx(Integer helpidx) {
		this.helpidx = helpidx;
	}


	public String getHtype() {
		return htype;
	}


	public void setHtype(String htype) {
		this.htype = htype;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getContents() {
		return contents;
	}


	public void setContents(String contents) {
		this.contents = contents;
	}


	public String getWriter() {
		return writer;
	}


	public void setWriter(String writer) {
		this.writer = writer;
	}


	public String getHprice() {
		return hprice;
	}


	public void setHprice(String hprice) {
		this.hprice = hprice;
	}


	public java.sql.Date getEdate() {
		return edate;
	}


	public void setEdate(java.sql.Date edate) {
		this.edate = edate;
	}


	public int getMidx() {
		return midx;
	}


	public void setMidx(int midx) {
		this.midx = midx;
	}


	@Override
	public String toString() {
		return "HelpVO [helpidx=" + helpidx + ", htype=" + htype + ", title=" + title + ", contents=" + contents
				+ ", writer=" + writer + ", hprice=" + hprice + ", edate=" + edate + ", midx=" + midx + "]";
	}

	
	
	
	
}
