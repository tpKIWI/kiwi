package help.service;

import java.util.List;
import java.util.Map;

import help.model.HelpVO;
import help.model.PagingVO;

public interface HelpService {

	int insertHelp(HelpVO help);
	
	/*List<HelpVO> selectHelpAll(Map<String,Integer> map);*/
	List<HelpVO> selectHelpAll(PagingVO paging);
	
	List<HelpVO> findHelp(PagingVO paging);		
	
	int getTotalCount();
	int getTotalCount(PagingVO paging);
	
	HelpVO selectHelpByhidx(Integer hidx);
	
	int deleteHelp(Integer helpidx);
	
	int updateHelp(HelpVO help);
	
}
