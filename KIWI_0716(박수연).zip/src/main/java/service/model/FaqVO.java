package service.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class FaqVO implements Serializable {
	
	
	private int fqidx; //질문번호
	private String title; //제목
	private String contents; //내용
	private int aidx; //관리자번호
	
	
	
	
	
	
	
	//-----------------------------
	
	public FaqVO(int fqidx, String title, String contents, int aidx) {
		super();
		this.fqidx = fqidx;
		this.title = title;
		this.contents = contents;
		this.aidx = aidx;
	}
	
	//-----------------------
	
	
	public int getFqidx() {
		return fqidx;
	}
	public void setFqidx(int fqidx) {
		this.fqidx = fqidx;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContents() {
		return contents;
	}
	public void setContents(String contents) {
		this.contents = contents;
	}
	public int getAidx() {
		return aidx;
	}
	public void setAidx(int aidx) {
		this.aidx = aidx;
	}

	@Override
	public String toString() {
		return "FaqVO [fqidx=" + fqidx + ", title=" + title + ", contents=" + contents + ", aidx=" + aidx + "]";
	}
	
	
	//----------------------------
	
	
	


}


