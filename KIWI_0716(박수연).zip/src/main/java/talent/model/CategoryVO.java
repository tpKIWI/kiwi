package talent.model;

import java.io.Serializable;

public class CategoryVO implements Serializable {

	// UP 및 DOWN 카테고리 관련 변수 선언
	private int upcode;
	private int downcode;
	private String upname;
	private String downname;
	
	// 기본 생성자
	public CategoryVO() {
		super();
	}

	// 인자 생성자
	public CategoryVO(int upcode, int downcode, String upname, String downname) {
		super();
		this.upcode = upcode;
		this.downcode = downcode;
		this.upname = upname;
		this.downname = downname;
	}

	// Getters, Setters
	public int getUpcode() {return upcode;}
	public void setUpcode(int upcode) {this.upcode = upcode;}

	public int getDowncode() {return downcode;}
	public void setDowncode(int downcode) {this.downcode = downcode;}

	public String getUpname() {return upname;}
	public void setUpname(String upname) {this.upname = upname;}

	public String getDownname() {return downname;}
	public void setDownname(String downname) {this.downname = downname;}

	@Override
	public String toString() {
		return "CategoryVO [upcode=" + upcode + ", downcode=" + downcode + ", upname=" + upname + ", downname="
				+ downname + "]";
	}

}
