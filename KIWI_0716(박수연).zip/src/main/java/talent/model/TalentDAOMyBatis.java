package talent.model;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import talent.model.TalentDAOMyBatis;

public class TalentDAOMyBatis extends SqlSessionDaoSupport {

	private final String NS="talent.model.TalentMapper";
	
	private static final Logger log
	=LoggerFactory.getLogger(TalentDAOMyBatis.class);
	
	@Resource(name="sqlSessionFactory")
	@Override
	public void setSqlSessionFactory(SqlSessionFactory sqlSessionFactory) {
		super.setSqlSessionFactory(sqlSessionFactory);
	}

}
