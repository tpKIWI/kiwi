-- 상위분류
ALTER TABLE up
	DROP CONSTRAINT PK_up; -- 상위분류 기본키

-- 상위분류
DROP TABLE up;

-- 상위분류
CREATE TABLE up (
	upcode NUMBER(10)   NOT NULL, -- 상위분류코드
	upname VARCHAR2(30) NOT NULL  -- 상위분류명
);

-- 상위분류 기본키
CREATE UNIQUE INDEX PK_up
	ON up ( -- 상위분류
		upcode ASC -- 상위분류코드
	);

-- 상위분류
ALTER TABLE up
	ADD
		CONSTRAINT PK_up -- 상위분류 기본키
		PRIMARY KEY (
			upcode -- 상위분류코드
		);
		
-- 상위분류 시퀀스
DROP SEQUENCE UP_UPCODE_SEQ;

CREATE SEQUENCE UP_UPCODE_SEQ
START WITH 1
INCREMENT BY 1
NOCACHE;		

DESC UP;

insert into up(upcode, upname)
values(up_upcode_seq.nextval, '디자인');

insert into up(upcode, upname)
values(up_upcode_seq.nextval, '광고및미디어');

insert into up(upcode, upname)
values(up_upcode_seq.nextval, '컴퓨터');

insert into up(upcode, upname)
values(up_upcode_seq.nextval, '번역및작성');

insert into up(upcode, upname)
values(up_upcode_seq.nextval, '핸드메이드');

commit;
select * from up;