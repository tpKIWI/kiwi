package user.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.springframework.stereotype.Repository;

@Repository("memberDAOMyBatis")
public class MemberDAOMyBatis extends SqlSessionDaoSupport implements MemberDAO{
	
	private final String NS = "user.model.MemberMapper";
	private SqlSession ses;
	
	@Resource(name="sqlSessionFactory")
	@Override
	public void setSqlSessionFactory(SqlSessionFactory sqlSessionFactory) {
		super.setSqlSessionFactory(sqlSessionFactory);
	}


	public int insertMember(MemberVO user) {
		ses = this.getSqlSession();
		int n = ses.insert(NS+".insertUser", user);
		return n;
	}

	public boolean idCheck(String userid) {
		ses = this.getSqlSession();
		// select idx from member where userid=?
		// 결과 테이블(rs) => 단일행(userid는 unique하므로)
		Integer idx = ses.selectOne(NS+".idCheck", userid);
		boolean result = (idx==null) ? true:false;
		//System.out.println("idx = "+idx);
		return result;
	}

	public int getTotalMember() {
		ses = this.getSqlSession();
		int total = ses.selectOne(NS+".totalCount");
		return total;
	}

	public List<MemberVO> getAllMembers() {
		ses = this.getSqlSession();
		List<MemberVO> arr = ses.selectList(NS+".listMember");
		
		return arr;
	}
	public List<MemberVO> getAllMembers(int start, int end) {
		ses = this.getSqlSession();
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("start", start);
		map.put("end", end);
		
		List<MemberVO> arr
			= ses.selectList(NS+".listMemberPaging", map);
		return arr;
	}

	public MemberVO findMemberByUserid(String userid) throws NotMemberException {
		ses = getSqlSession();
		MemberVO user = ses.selectOne(NS+".findMemberByUserid", userid);
		return user;
	}

	public MemberVO isLoginOK(String userid, String pwd) throws NotMemberException {
		MemberVO dbUser = this.findMemberByUserid(userid);
		if(dbUser == null){
			throw new NotMemberException(userid+"는 존재하지 않습니다.");
		}
		if(!pwd.equals(dbUser.getPwd())){
			// 비번 불일치 시 예외 발생
			throw new NotMemberException("비밀번호가 틀려요.");
		}
		return dbUser;	// 최종적으로 회원 인증을 받은 MemberVO를 반환
	}

	public MemberVO findMemberByIdx(Integer idx) {
		ses=this.getSqlSession();
		MemberVO vo=ses.selectOne(NS+".findMember",idx);
		return vo;
	}

	public int deleteMember(Integer idx) {
		ses = this.getSqlSession();
		int n = ses.delete(NS+".deleteMember", idx);
		return n;
	}

	public int updateMember(MemberVO user) {
		ses = this.getSqlSession();
		int n = ses.delete(NS+".updateMember", user);
		return n;
	}

	public List<MemberVO> findMember(String colType, String key) {
		return null;
	}


	public int findMemberTotal(String colType, String keyword) {
		ses = this.getSqlSession();
		
		Map<String, String> map	= new HashMap<String, String>();
		// colType 값 => 컬럼명(name, userid, addr1, email)
		map.put("findType", colType);	
		map.put("findKeyword", keyword);
		int total = ses.selectOne(NS+".findMemberTotal", map);
		return total;
	}

	public List<MemberVO> findMember(String colType, String keyword, int start, int end) {
		Map<String, String> map	= new HashMap<String, String>();
		// colType 값 => 컬럼명(name, userid, addr1, email)
		map.put("findType", colType);	
		map.put("findKeyword", keyword);
		map.put("start", String.valueOf(start));
		map.put("end", String.valueOf(end));
		
		ses = this.getSqlSession();
		List<MemberVO> arr
			= ses.selectList(NS+".findMemberPaging", map);
		
		return arr;
	}

}
