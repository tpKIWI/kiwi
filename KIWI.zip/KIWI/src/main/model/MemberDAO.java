package user.model;

import java.util.List;

public interface MemberDAO {
	
	/* 검색이나 로그인 시*/
	public MemberVO findMemberByUserid(String userid)
	throws NotMemberException;
	
	/** 회원가입 */
	public int insertMember(MemberVO user);
	public boolean idCheck(String userid);
	
	/**회원 목록 가져오기 */
	public List<MemberVO> getAllMembers();
	/**회원 목록 가져오기 - 페이징 처리 */
	public List<MemberVO> getAllMembers(int start, int end);
	
	/* 총 회원 수 가져오기*/
	public int getTotalMember();
	
	/** 로그인 처리 */
	public MemberVO isLoginOK(String userid, String pwd)
	throws NotMemberException;
	
	/** 회원번호로 회원정보 가져오기 */
	public MemberVO findMemberByIdx(Integer idx);
	
	/** 회원탈퇴 또는 회원정보 삭제 */
	public int deleteMember(Integer idx);
	
	/** 회원정보 수정 */
	public int updateMember(MemberVO user);
	
	/** 회원정보 검색 */
	public List<MemberVO> findMember(String colType, String key);
	/** 회원정보 검색 - 검색한 결과 회원 수 */
	public int findMemberTotal(String colType, String key);
	/** 회원정보 검색 - 페이징 처리 */
	public List<MemberVO> findMember(String colType, String key, int start, int end);
}
