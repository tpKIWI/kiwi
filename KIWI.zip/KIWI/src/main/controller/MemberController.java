package user.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import common.service.ShopService;
import user.model.MemberVO;

@Controller
public class MemberController {

	@Autowired
	private ShopService shop;
	
	/* Logger 에러나면 slf4j import할 것 
	 * 
	 * */
	private static final Logger log
		=LoggerFactory.getLogger(MemberController.class);
	
	/** 회원가입 폼 보여주기 - GET 방식 요청 시 */
	@RequestMapping(value="/join.do", method=RequestMethod.GET)
	public String memberJoin(){
		
		return "member/member";
	}
	
	/** 회원가입 처리 - POST 방식 요청 시 */
	@RequestMapping(value="/join.do", method=RequestMethod.POST)
	public String memberJoinEnd
		(Model model, @ModelAttribute("user") MemberVO user){
		// ModelAttribute를 이용하여 VO의 set 계열 메소드로 
		// 값을 쏙쏙 넣어준다. 일일이 다 request.getParameter()로
		// 할 수 없으니까! user-user 같아야 하는 것 주의!
		
		int n = shop.insertMember(user);
		
		String msg=(n>0)?"회원가입 성공" : "가입 실패";
		String loc=(n>0)?"memberList.do" : "javascript:history.back()";
				
		model.addAttribute("msg", msg);
		model.addAttribute("loc", loc);
		
		return "memo/message";
	}
	
	/** 회원가입 관련 - 아이디 중복 체크 */
	// 항상 버튼 눌러서 하는건 GET 방식
	@RequestMapping(value="/idCheck.do", method=RequestMethod.GET)
	public String idCheckForm(){
		
		return "member/idCheck";	// WEB-INF/view/member/idCheck.jsp
	}
	
	// 아이디 중복체크를 눌렀을 때 checkId로 가면서 POST 방식
	@RequestMapping(value="/idCheck.do", method=RequestMethod.POST)
	public String idCheckEnd
		(Model model,@RequestParam(defaultValue="")String userid){
		System.out.println("userid="+userid);
		if(userid.isEmpty()){
			model.addAttribute("msg", "잘못 들어온 경로입니다.");
			model.addAttribute("loc", "javascript:history.back()");
			
			return "memo/message";
		}
		
		boolean bool = shop.idCheck(userid);
		// true 반환하면 사용가능
		// false 반환하면 이미 존재하는 아이디
		model.addAttribute("result", bool);
		model.addAttribute("userid", userid);
		
		return "member/idCheck";	// WEB-INF/view/member/idCheck.jsp
	}

	@RequestMapping("/idCheckAjax0.do")
	public String idCheck(Model model,
			@RequestParam(defaultValue="") String userid)
	{
		boolean bool=shop.idCheck(userid);
		model.addAttribute("result",bool);
		model.addAttribute("userid",userid);
		return "member/idCheckJson";
	}
	
	/* 스프링에서 JSON 데이터를 생성해야 하는 경우 아래와 같이 
	@ResponseBody 어노테이션을 사용하면	간단히 처리할 수 있다. 
	[1] 단 pom.xml을 이용해서 Jackson-databind 라이브러리를 추가해야한다.
		=== pom.xml에 추가 ===============================
		<dependency>
			<groupId>com.fasterxml.jackson.core</groupId>
			<artifactId>jackson-databind</artifactId>
			<version>2.5.4</version>
		</dependency>
		=================================================
	[2] 스프링 컨트롤러에서 json 데이터를 생성하기 위해	반환 타입을 
		VO 또는 DTO, Map 등의 적절한 객체를 반환해주고
		@ResponseBody 어노테이션을 추가한다. 우리는 Map을 반환하자. */
	@RequestMapping("/idCheckAjax.do")
	public @ResponseBody Map<String, String>idCheck
		(HttpServletResponse res, @RequestParam(defaultValue="") String userid){
		// 캐시 사용 안하도록
		res.setHeader("Cache-Control","no-cache");
		boolean bool = shop.idCheck(userid.trim());
		Map<String, String> map = new HashMap<String, String>();
		map.put("result", String.valueOf(bool));
		map.put("userid", userid);
		
		return map;
		/* 뷰 페이지를 지정할 필요가 없음. 
		 * Jackson-databind 라이브러리가 Map이나 VO 객체의 프로퍼티와 
		 * 값을 꺼내 xxx.json 파일 형태를 만들어준다. */
	}
	
	
	/** 전체 회원 목록 보기 */
	// default가 get이라 굳이 method 지정 안함.
	@RequestMapping(value="/memberList.do")
	public String listMember(Model model, @RequestParam(defaultValue="1") int cpage){
		// 총 회원 수 가져오기
		int total = shop.getTotalMember(); 
		int pageSize=5;
		int pageCount=(total-1)/pageSize+1;
		
		if(cpage < 1){cpage=1;}
		if(cpage > pageCount){cpage=pageCount;}
		
		int end=cpage*pageSize;
		int start = end-(pageSize-1);
		
		/* shop의 getAllMembers() 호출해서 반환받은 값을 
		 * Model 객체에 저장. key값 : "userList" */
		// shopserviceImple -> mybatis -> memberMapper
		List<MemberVO> arr = shop.getAllMembers(start, end);
		
		model.addAttribute("userList", arr);
		model.addAttribute("userTotal", total);
		model.addAttribute("pageCount", pageCount);
		model.addAttribute("cpage", cpage);
		return "member/memberList";
	}
	
	/** 검색한 회원 목록 보기 */
	// default가 get이라 굳이 method 지정 안함.
	@RequestMapping(value="/memberFind.do")
	public String findMember(Model model, 
			@RequestParam(defaultValue="0") int findType,
			@RequestParam(defaultValue="") String findString,
			@RequestParam(defaultValue="1") int cpage){
		
		String colType="";
		switch(findType){
			case 0: colType="name";		break;
			case 1: colType="userid";	break; 
			case 2: colType="email";	break;
			case 3: colType="addr1";	break;
		}
		
		// 검색한 총 회원 수 가져오기
		int total = shop.findMemberTotal(colType, findString); 
		int pageSize=2;
		int pageCount=(total-1)/pageSize+1;
		
		if(cpage < 1){cpage=1;}
		if(cpage > pageCount){cpage=pageCount;}
		
		int end=cpage*pageSize;
		int start = end-(pageSize-1);
		
		/* shop의 getAllMembers() 호출해서 반환받은 값을 
		 * Model 객체에 저장. key값 : "userList" */
		// shopserviceImple -> mybatis -> memberMapper

		// 검색한 회원 목록 가져오기
		List<MemberVO> arr
			= shop.findMember(colType, findString, start, end);
		
		model.addAttribute("userList", arr);
		model.addAttribute("userTotal", total);
		model.addAttribute("pageCount", pageCount);
		model.addAttribute("cpage", cpage);
		return "member/memberFind";
	}
	
	@RequestMapping(value="/memberDel.do", method=RequestMethod.POST)
	public String deleteMember
		(Model model, @RequestParam(defaultValue="0") int idx){
		System.out.println("idx="+idx);
		if(idx==0){
			return "redirect:/memberList.do";
		}
		
		/* logback.xml에서
		<root level="info"> 
			<appender-ref ref="console"/>
		</root>
		부분을 찾아 info를 debug로 수정하면 된다. 
		개발 시에는 debug로 하면 로그 기록을 보면서 디버깅할 수 있고
		개발이 완료되고 나서는 info로 바꾸면 로그 기록이 남지 않아
		콘솔 창을 깨끗하게 유지할 수 있다. */
		log.debug("파라미터 idx={}", idx);
		
		int n = shop.deleteMember(idx);
		
		String msg=(n>0)?"삭제 성공" : "삭제 실패";
		String loc=(n>0)?"memberList.do" : "javascript:history.back()";
		
		model.addAttribute("msg", msg);
		model.addAttribute("loc", "memberList.do");
		
		return "memo/message";
	}
	
	@RequestMapping(value="/memberEdit.do", method=RequestMethod.POST)
	public String editForm
		(Model model,	@RequestParam(defaultValue="0") int idx){
		log.debug("editForm() idx={}",idx); 
		MemberVO user=shop.findMemberByIdx(idx);
		model.addAttribute("user",user);
		
		return "member/memberEdit";
	}
	
	@RequestMapping(value="/memberEditEnd.do",
			method=RequestMethod.POST)
	public String editEnd(Model model,
			@ModelAttribute("user") MemberVO user)
	{
		log.debug("editEnd() user={}",user);
		int n=shop.updateMember(user);
		String msg=(n>0)?"수정 성공":"수정 실패";
		String loc=(n>0)?"memberList.do":
			"javascript:history.back()";
		model.addAttribute("msg",msg);
		model.addAttribute("loc",loc);
		return "memo/message";
	}
	
}
