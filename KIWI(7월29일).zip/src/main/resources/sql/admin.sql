-- 관리자
ALTER TABLE admin
	DROP CONSTRAINT PK_admin; -- 관리자 기본키

-- 관리자
DROP TABLE admin;

-- 관리자
CREATE TABLE admin (
	aidx   NUMBER(5)    NOT NULL, -- 관리자번호
	aemail VARCHAR2(50) NOT NULL, -- 이메일
	apwd   VARCHAR2(16) NOT NULL  -- 비밀번호
);

-- 관리자 기본키
CREATE UNIQUE INDEX PK_admin
	ON admin ( -- 관리자
		aidx ASC -- 관리자번호
	);

-- 관리자
ALTER TABLE admin
	ADD
		CONSTRAINT PK_admin -- 관리자 기본키
		PRIMARY KEY (
			aidx -- 관리자번호
		);
		
CREATE SEQUENCE admin_aidx_SEQ NOCACHE;

--------------------------------------------------------------------------------
insert into admin values(1,'ww@ww.ww',1234);
select * from admin;

commit;