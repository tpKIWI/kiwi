package service.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import service.model.FaqDAO;
import service.model.FaqVO;

//import board.model.BoardDAO;
//import board.model.BoardVO;
//import board.model.PagingVO;
//import board.model.ReplyVO;



@Service
public class FaqServiceImpl implements FaqService {

	@Autowired
	private FaqDAO faqDao;


	public int faqInsert(FaqVO faq){
		return faqDao.faqInsert(faq);
	}
	
/*	public int insertBoard(FaqVO board) {
		return boardDao.insertBoard(board);
	}

	public List<FaqVO> selectBoardAll(
			Map<String, Integer> map) {
		return boardDao.selectBoardAll(map);
	}

	public List<FaqVO> selectBoardAll(
			PagingVO paging) {
		return boardDao.selectBoardAll(paging);
	}

	public int getTotalCount() {
		return boardDao.getTotalCount();
	}
	public int getTotalCount(PagingVO page) {
		return boardDao.getTotalCount(page);
	}

	public boolean updateReadnum(Integer idx) {
		return boardDao.updateReadnum(idx); 
	}

	public FaqVO selectBoardByIdx(Integer idx) {
		return boardDao.selectBoardByIdx(idx);
	}

	public String selectPwd(Integer idx) {
		return boardDao.selectPwd(idx);
	}

	public int deleteBoard(Integer idx) {
		return boardDao.deleteBoard(idx);
	}

	public int updateBoard(FaqVO board) {
		return boardDao.updateBoard(board);
	}

	public int insertReply(ReplyVO reply) {
		return boardDao.insertReply(reply);
	}

	public List<ReplyVO> selectReplyAll(Integer idx) {
		return boardDao.selectReplyAll(idx);
	}

	public int selectReplyCount(Integer idx){
		return boardDao.selectReplyCount(idx);
	}

	public int deleteReply(Integer num) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int rewriteBoard(FaqVO board) {
		return boardDao.rewriteBoard(board);
	}
*/
}






