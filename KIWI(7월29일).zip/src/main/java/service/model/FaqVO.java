package service.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class FaqVO implements Serializable {
	
	
	private int fqidx; //질문번호
	private String title; //제목
	private String contents; //내용
	private String cate_cd; //카테고리코드
	private String cate_nm; //카테고리명
	private int aidx; //관리자번호
	
	
	
	public FaqVO() {
	
	}



	public FaqVO(int fqidx, String title, String contents, String cate_cd, String cate_nm, int aidx) {
		super();
		this.fqidx = fqidx;
		this.title = title;
		this.contents = contents;
		this.cate_cd = cate_cd;
		this.cate_nm = cate_nm;
		this.aidx = aidx;
	}



	public int getFqidx() {
		return fqidx;
	}



	public void setFqidx(int fqidx) {
		this.fqidx = fqidx;
	}



	public String getTitle() {
		return title;
	}



	public void setTitle(String title) {
		this.title = title;
	}



	public String getContents() {
		return contents;
	}



	public void setContents(String contents) {
		this.contents = contents;
	}



	public String getCate_cd() {
		return cate_cd;
	}



	public void setCate_cd(String cate_cd) {
		this.cate_cd = cate_cd;
	}



	public String getCate_nm() {
		return cate_nm;
	}



	public void setCate_nm(String cate_nm) {
		this.cate_nm = cate_nm;
	}



	public int getAidx() {
		return aidx;
	}



	public void setAidx(int aidx) {
		this.aidx = aidx;
	}



	@Override
	public String toString() {
		return "FaqVO [fqidx=" + fqidx + ", title=" + title + ", contents=" + contents + ", cate_cd=" + cate_cd
				+ ", cate_nm=" + cate_nm + ", aidx=" + aidx + "]";
	}
	
	
	


}


