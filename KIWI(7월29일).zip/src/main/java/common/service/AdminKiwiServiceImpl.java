package common.service;


import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import admin.model.AdminDAO;
import admin.model.AdminVO;
import member.model.NotMemberException;

@Service
public class AdminKiwiServiceImpl implements AdminKiwiService {

	@Resource(name="adminDAOMyBatis")
	
	private AdminDAO adminDao;



	public int adminEmailCheck(String aemail) {
		return adminDao.adminEmailCheck(aemail);
	}

	public AdminVO isAdminLoginOK(String aemail, String apwd) throws NotMemberException {
		return adminDao.isAdminLoginOK(aemail, apwd);
	}

	public AdminVO findAdminByIdx(Integer aidx) {
		return adminDao.findAdminByIdx(aidx);
	}

	public AdminVO findByAdminEmail(String aemail) 
			throws NotMemberException {
		
		return adminDao.findByAdminEmail(aemail);
	}

	
}
	

