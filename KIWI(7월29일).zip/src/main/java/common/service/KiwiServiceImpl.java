package common.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import member.model.MemberDAO;
import member.model.MemberVO;
import member.model.NotMemberException;
import talent.model.CategoryVO;
import talent.model.ReviewVO;
import talent.model.TalentDAO;
import talent.model.TalentVO;

@Service
public class KiwiServiceImpl implements KiwiService{
	
	/** 재능 관련 ******************************************************************** */
	@Resource(name="talentDAOMyBatis")
	private TalentDAO talentDao;
	
	
	public List<CategoryVO> getUpCategory() {
		return talentDao.getUpCategory();
	}

	public List<CategoryVO> getUpCategory(int upCode) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<CategoryVO> getDwCategory(int upcode) {
		return talentDao.getDwCategory(upcode);
	}

	public List<TalentVO> allTalentList() {
		return talentDao.allTalentList();
	}

	public List<CategoryVO> infoByUpCate(int upcode) {
		return talentDao.infoByUpCate(upcode);
	}
	
	public List<TalentVO> selectByUpCate(int upcode) {
		return talentDao.selectByUpCate(upcode);
	}
	
	@Resource(name="memberDAOMyBatis")
	private MemberDAO memberDao;

	public List<TalentVO> selectByDwCate(int upcode, int dwcode) {
		return talentDao.selectByDwCate(upcode, dwcode);
	}
	
	public TalentVO selectByTnum(int tnum) {
		return talentDao.selectByTnum(tnum);
	}

	/** [회원권한] 재능 등록하기 */
	public int insertTalent(TalentVO talent){
		return talentDao.insertTalent(talent);
	}
	
	/** [회원권한] 재능 수정하기 */
	public int updateTalent(TalentVO talent) {
		return talentDao.updateTalent(talent);
	}
	
	/** [회원, 관리자 권한] 재능 삭제하기 */
	public int deleteTalent(int tnum){
		return talentDao.deleteTalent(tnum);
	};
	
	/** 상위분류명 및 하위분류명 가져오기 */
	public CategoryVO getUpDwName(int tnum){
		return talentDao.getUpDwName(tnum);
	}
	/** 재능 검색하기 */
	public List<TalentVO> searchTalent(String keyword){
		return talentDao.searchTalent(keyword);
	}
	
	/** 후기 관련 ******************************************************************** */
	public List<ReviewVO> getRvList(int tnum){
		return talentDao.getRvList(tnum);
	}
	
	public ReviewVO selectByRnum(int rnum){
		return talentDao.selectByRnum(rnum);
	}
	
	/** 전체 후기 가져오기 */
	public List<ReviewVO> allReviewList(){
		return talentDao.allReviewList();
	}
	
	public int insertReview(ReviewVO review) {
		return talentDao.insertReview(review);
	}

	public int updateReview(ReviewVO review) {
		return talentDao.updateReview(review);
	}

	public int deleteReview(int rnum) {
		return talentDao.deleteReview(rnum);
	}
	
	/** 총 리뷰 갯수 가져오기 */
	public int getRvCount(int tnum){
		return talentDao.getRvCount(tnum);
	}
	
	/** 리뷰 평점 내기 */
	public int getRscoreAvg(int tnum){
		return talentDao.getRscoreAvg(tnum);
	}
	
	/** 회원 관련 ******************************************************************** */
	public int insertMember(MemberVO member) {
		int n = memberDao.insertMember(member);
		return n;
	}

	public MemberVO findMemberByEmail(String email1) throws NotMemberException {
		return null;
	}

	public int emailCheck(String email) {
		return memberDao.emailCheck(email);
	}

	public MemberVO isLoginOK(String email1, String pwd1) throws NotMemberException {
		return memberDao.isLoginOK(email1, pwd1);
	}
	
	public MemberVO selectByMidx(int midx){
		return memberDao.selectByMidx(midx);
	}

}
