package service.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class FaqController {

	@RequestMapping("/service/faqListView.do")
	public void showIndex(){
		
	}
	
	@RequestMapping("/service/faqInsertView.do")
	public void faqInsertView(){
		
	}
	
}
