package my.com;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloController {
	@RequestMapping("/hello.do")
	public String execute(Model model){
		model.addAttribute("greeting", "안녕하세요?");
		model.addAttribute("name", "홍길동");
		return "helloView";	// 뷰네임
		// WEB-INF/view/helloView.jsp
	}
}
