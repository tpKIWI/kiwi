package service.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class NoticeController {
	
	@RequestMapping("/service/noticeList.do")
	public void noticeIndex(){
		
	}
	
	@RequestMapping("/service/noticeInsert.do")
	public void noticeInsert(){
		
	}
	
	@RequestMapping("/service/noticeView.do")
	public void noticeView(){
		
	}
	
	@RequestMapping("/service/noticeUpdate.do")
	public void noticeUpdate(){
		
	}
	
}
