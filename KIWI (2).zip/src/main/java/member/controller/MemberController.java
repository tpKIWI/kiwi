package member.controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import common.service.KiwiService;
import member.model.MemberVO;


@Controller
public class MemberController {
	
	
	@Autowired
	private KiwiService kiwi;
	
	
	/**회원가입 폼 보여주기*/
	@RequestMapping(value="/member/memberjoin.do",method=RequestMethod.GET)
	public String memberjoin(){
		return "member/memberjoin";
	}
	
	/**회원가입 처리-POST*/
	@RequestMapping(value="/member/memberjoin.do",method=RequestMethod.POST)
	public String memberjoinEnd(Model model,
			@ModelAttribute("member") MemberVO member)
	{
		
		int n = kiwi.insertMember(member);
		
		String msg=(n>0)?"회원가입에 성공하였습니다!":"회원가입에 실패하였습니다.";
		String loc=(n>0)?"/KIWI/kiwi/home.do":"javascript:history.back()";
		
		model.addAttribute("msg",msg);
		model.addAttribute("loc",loc);
		
		return "memo/message";
	}
	
	@RequestMapping(value="/emailCheck.do",method=RequestMethod.POST)
	public @ResponseBody int emailCheckForm(
			HttpServletResponse res,@RequestParam(defaultValue="")String email){
		res.setHeader("Cache-Control", "no-cache");
		int n = kiwi.emailCheck(email.trim());
		return n;
	}
	
	
	@RequestMapping("/member/mypage.do")
	public void mypage(){
		
	}
	@RequestMapping("/member/accountset.do")
	public void accountset(){
		
	}
	@RequestMapping("/member/mybuy/mybuy.do")
	public void mybuy(){
		
	}
	@RequestMapping("/member/mybuy/buydetail.do")
	public void buydetail(){
		
	}
	@RequestMapping("/member/mysell/mysell.do")
	public void mysell(){
		
	}
	@RequestMapping("/member/mysell/selldetail.do")
	public void selldetail(){
		
	}
	@RequestMapping("/member/mypageajax/ajaxregtalent.do")
	public void ajaxregtalent(){
		
	}
}
