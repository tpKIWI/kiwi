package common.service;


import org.springframework.stereotype.Service;
import javax.annotation.*;
import member.model.MemberDAO;
import member.model.MemberVO;
import member.model.NotMemberException;

@Service
public class KiwiServiceImpl implements KiwiService {

	@Resource(name="memberDAOMyBatis")
	private MemberDAO memberDao;
	
	public int insertMember(MemberVO member) {
		int n = memberDao.insertMember(member);
		return n;
	}

	public MemberVO findMemberByEmail(String email1) throws NotMemberException {
		// TODO Auto-generated method stub
		return null;
	}

	public int emailCheck(String email) {
		return memberDao.emailCheck(email);
	}

	public MemberVO isLoginOK(String email1, String pwd1) throws NotMemberException {
		return memberDao.isLoginOK(email1, pwd1);
	}


}
