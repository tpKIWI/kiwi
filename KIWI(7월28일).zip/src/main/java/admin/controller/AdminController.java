package admin.controller;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import common.service.AdminKiwiService;
import common.util.CommonUtil;
@RequestMapping("/admin")
@Controller
public class AdminController {
	@Autowired
	private AdminKiwiService akiwi;
	
	@Autowired
	private CommonUtil util;

	
	
	@RequestMapping(value="adminlogin.do",
			method=RequestMethod.GET)
	public String adminlogin(){
		return "admin/adminlogin";
	}
	
	
	@RequestMapping(value="/adminemailCheck.do",method=RequestMethod.POST)
	public @ResponseBody int adminemailCheck(
			HttpServletResponse res,@RequestParam(defaultValue="")String aemail){
		res.setHeader("Cache-Control", "no-cache");
		int n = akiwi.adminEmailCheck(aemail.trim());
		return n;
	}
	
	@RequestMapping("/common/msg.do")
	public String showMsg(){
		return "memo/message";
	}
	
	@RequestMapping("admin/adminmain.do")
	public void adminmain(){
		
	}
	@RequestMapping("admin/admindetail.do")
	public void admindetail(){
		
	}
	
}
