package help.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import common.util.CommonUtil;
import help.model.SuggestVO;
import help.service.HelpService;

public class ReplyController {

	@Autowired
	private HelpService helpService;
	
	@Autowired
	private CommonUtil util;
	
	@RequestMapping("/member/help/suggest.do")
	public String suggestInsert(Model model,
			@ModelAttribute("suggest") SuggestVO svo){
		int n = helpService.insertSuggest(svo);
		String msg=(n>0)?"제안하기 성공!":"제안하기 실패!";
		String loc="../../help/helpDetail.do?helpidx="+svo.getHelpidx();
		return util.addMsgLoc(model, msg, loc);
	}
	
}
