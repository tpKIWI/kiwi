package talent.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import common.service.KiwiService;
import common.util.CommonUtil;
import talent.model.TalentVO;

@Controller
@RequestMapping("/member/talent")
public class OrderController {
	@Autowired
	private KiwiService kiwi;
	
	@Autowired
	private CommonUtil util;
	
	private static Logger log = LoggerFactory.getLogger(OrderController.class);
	
	@RequestMapping("/orderSheet.do")
	public String orderSheet(Model model,HttpSession ses,
			@RequestParam("otnum")int[] otnum,
			@RequestParam("oqty")int[] oqty){
		log.debug("orderSheet(): otnum={}", otnum);
		log.debug("orderSheet(): oqty={}", oqty);
		
		// 주문한 상품 정보 가져오기
		List<TalentVO> orderList = new ArrayList<TalentVO>();
		
		if(otnum != null){
			for(int i=0; i < otnum.length; i++){
				int tnum = otnum[i];	// 주문한 상품 번호
				int qty = oqty[i];		// 주문 수량
			
				// 주문한 상품정보를 db에서 가져오고
				TalentVO talent = kiwi.selectByTnum(tnum);
				
				// 주문한 상품 수량으로 변경
				talent.setTqty(qty);
				orderList.add(talent);
			}
		}
		
		// 주문한 상품 정보를 저장
		model.addAttribute("orderList", orderList);
		
		// 주문 상품 정보를 세션에 저장
		ses.setAttribute("orderList", orderList);
		
		return "shop/orderSheet";
	}
	
	/* 주문 처리하는 메소드 
	@RequestMapping(value="/orderEnd.do", method=RequestMethod.POST)
	public String orderEnd(Model model, HttpSession ses, 
			@ModelAttribute("ovo") OrderVO ovo, 
			@ModelAttribute("receiver") ReceiverVO receiver){
		
		log.info("주문정보 ovo={}", ovo);
		// ototalPrice, ototalPoint, midx_fk, 수령자명
		
		// 1. 주문한 상품 정보 가져오기
		List<ProductVO> orderList = (List<ProductVO>)ses.getAttribute("orderList");
		
		// 2. 주문한 상품 정보와 3. 수령자 정보를 ovo에 셋팅
		if(ovo.getPayMethod()==311){
			ovo.setOpaystate("미결제");
		}else if(ovo.getPayMethod()==312){
			ovo.setOpaystate("결제완료");
		}
		
		ovo.setOrderList(orderList);
		ovo.setReceiver(receiver);
		log.info("receiver post={}",receiver.getPost());
		
		// 4. 주문 정보를 DB에 insert 한다.
		String onum = shop.orderInsert(ovo);
		
		// 5. 주문번호를 세션에 저장
		ses.setAttribute("onum", onum);
		
		// 6. 회원정보를 db에서 가져와 세션에 다시 저장
		// 적립금 등의 변동이 있으므로
		MemberVO loginUser = shop.findMemberByIdx(ovo.getMidx_fk());
		ses.setAttribute("loginUser", loginUser);
		// 7. 주문 처리가 완료되면 => 장바구니에서 주문 완료된 상품만 삭제한다.
		// 							  (회원번호, 주문한 상품번호)
		if(orderList != null){
			for(ProductVO pd:orderList){
				shop.deleteCartByIdx(ovo.getMidx_fk(), pd.getPnum());
			}
		}
		
		 주문 상세 내역 보여주는 페이지로 리다이렉트 이동.
		 * 새로고침 시 이중 주문이 발생할 수 있기 때문에 
		 * forward가 아니라 redirect로 이동한다. 
		return "redirect:orderDetail.do";	
	}
	
	@RequestMapping("/orderDetail.do")
	public String orderFinish(Model model, 
			HttpSession ses, @RequestParam(defaultValue="")String onum){
		
		if(onum.isEmpty()){
			// 파라미터로 주문번호가 넘어오지 않았다면
			// 세션에 저장된 주문번호 꺼내기
			onum = (String) ses.getAttribute("onum");
		}
		if(onum == null){
			return util.addMsgBack(model, "잘못 들어온 경로입니다.");
		}
		// db에서 상세 주문 내역 가져오기
		List<OrderVO> orderDesc=shop.getOrderDesc(onum);
		log.debug("*****************************");
		log.info("orderDesc={}, orderDesc");
		log.debug("*****************************");
		model.addAttribute("orderDesc", orderDesc);
		model.addAttribute("onum", onum);
		return "shop/orderDesc";
	}
*/	
	
}
