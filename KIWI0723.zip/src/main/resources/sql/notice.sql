-- 고객센터_공지사항
ALTER TABLE notice
	DROP CONSTRAINT FK_admin_TO_notice; -- 관리자 -> 고객센터_공지사항

-- 고객센터_공지사항
ALTER TABLE notice
	DROP CONSTRAINT PK_notice; -- 고객센터_공지사항 기본키

-- 고객센터_공지사항
DROP TABLE notice;

-- 고객센터_공지사항
CREATE TABLE notice (
	nidx     NUMBER(5)      NOT NULL, -- 공지글번호0
	title    VARCHAR2(30)   NOT NULL, -- 제목
	contents VARCHAR2(1000) NOT NULL, -- 내용
	writer   VARCHAR2(50)   NULL,     -- 작성자
	wdate    DATE           NULL,     -- 작성일
	READNUM  NUMBER(20)     DEFAULT 0,     -- 조회수
	impt     VARCHAR2(10)   NULL,     -- 중요도
	clip     VARCHAR2(200)  NULL,     -- 첨부파일
	aidx     NUMBER(5)      NULL      -- 관리자번호
);

-- 고객센터_공지사항 기본키
CREATE UNIQUE INDEX PK_notice
	ON notice ( -- 고객센터_공지사항
		nidx ASC -- 공지글번호
	);

-- 고객센터_공지사항
ALTER TABLE notice
	ADD
		CONSTRAINT PK_notice -- 고객센터_공지사항 기본키
		PRIMARY KEY (
			nidx -- 공지글번호
		);

-- 고객센터_공지사항
ALTER TABLE notice
	ADD
		CONSTRAINT FK_admin_TO_notice -- 관리자 -> 고객센터_공지사항
		FOREIGN KEY (
			aidx -- 관리자번호
		)
		REFERENCES admin ( -- 관리자
			aidx -- 관리자번호
		);
		
DROP SEQUENCE notice_nidx_SEQ;

CREATE SEQUENCE notice_nidx_SEQ NOCACHE;

------------------------------------------------------------------------------
	nidx     NUMBER(5)      NOT NULL, -- 공지글번호0
	title    VARCHAR2(30)   NOT NULL, -- 제목
	contents VARCHAR2(1000) NOT NULL, -- 내용
	writer   VARCHAR2(50)   NULL,     -- 작성자
	wdate    DATE           NULL,     -- 작성일
	READNUM  NUMBER(20)     DEFAULT 0,     -- 조회수
	impt     VARCHAR2(10)   NULL,     -- 중요도
	clip     VARCHAR2(200)  NULL,     -- 첨부파일
	aidx     NUMBER(5)      NULL      -- 관리자번호

--------------------------------------------------------------------------------

-- 관리자
ALTER TABLE admin
	DROP CONSTRAINT PK_admin; -- 관리자 기본키

-- 관리자
DROP TABLE admin;

-- 관리자
CREATE TABLE admin (
	aidx   NUMBER(5)    NOT NULL, -- 관리자번호
	aemail VARCHAR2(50) NOT NULL, -- 이메일
	apwd   VARCHAR2(16) NOT NULL  -- 비밀번호
);

-- 관리자 기본키
CREATE UNIQUE INDEX PK_admin
	ON admin ( -- 관리자
		aidx ASC -- 관리자번호
	);

-- 관리자
ALTER TABLE admin
	ADD
		CONSTRAINT PK_admin -- 관리자 기본키
		PRIMARY KEY (
			aidx -- 관리자번호
		);
		
    
--------------------------------------------------------------------------------
insert into admin values(
1,'ww@ww.ww',1234
);
select * from admin;

select * from notice;
insert into notice values(notice_nidx_seq.nextval,'제목','내용','고양이',sysdate,default,'중요','img',1);

commit;