package common.service;

import java.util.List;

import member.model.MemberVO;
import member.model.NotMemberException;
import talent.model.CategoryVO;
import talent.model.ReviewVO;
import talent.model.TalentVO;

public interface KiwiService {

	/****************** 재능 관련 메소드 ******************/
	/** 상위 분류 가져오기*/
	public List<CategoryVO> getUpCategory();
	
	/** 상위 분류 코드로 특정 상위 분류 정보 가져오기*/
	public List<CategoryVO> getUpCategory(int upCode);
	
	/** 하위 분류 가져오기*/
	public List<CategoryVO> getDwCategory(int upcode);
	
	/** 전체 재능 목록 가져오기 */
	public List<TalentVO> allTalentList();

	/** 상위분류 정보(코드, 이름) 및 해당 상위분류의 하위분류 정보 가져오기 */
	public List<CategoryVO> infoByUpCate(int upcode);

	/** 해당 상위분류의 전체 재능목록 가져오기 */
	public List<TalentVO> selectByUpCate(int upcode);
	
	/** 해당 하위분류의 정보(코드, 이름) 가져오기 */
	/*public List<CategoryVO> infoByDwCate(int dwcode);*/
	
	/** 해당 하위분류의 전체 재능목록 가져오기 */
	public List<TalentVO> selectByDwCate(int upcode, int dwcode);

	/** 재능 번호로 특정 재능 가져오기 */
	public TalentVO selectByTnum(int tnum);
	
	/** [회원권한] 재능 등록하기 */
	public int insertTalent(TalentVO talent);
	
	/** [회원권한] 재능 수정하기 */
	public int updateTalent(TalentVO talent);
	
	/** [회원, 관리자 권한] 재능 삭제하기 */
	public int deleteTalent(int tnum);
	
	/** 상위분류명 및 하위분류명 가져오기 */
	public CategoryVO getUpDwName(int tnum);

	/** 재능 검색하기 */
	public List<TalentVO> searchTalent(String keyword);

	/****************** 후기 관련 메소드 ******************/
	/** 해당 재능에 대한 후기 (재능번호로) 가져오기 */
	public List<ReviewVO> getRvList(int tnum);
	
	/** 후기글번호로 후기 내용 가져오기 */
	public ReviewVO selectByRnum(int rnum);

	/** 후기 작성하기 */
	public int insertReview(ReviewVO review);
	
	/** 후기 수정하기 */
	public int updateReview(ReviewVO review);
	
	/** 후기 삭제하기 */
	public int deleteReview(int rnum);

	/** 총 리뷰 갯수 가져오기 */
	public int getRvCount(int tnum);
	
	/** 리뷰 평점 내기 */
	public int getRscoreAvg(int tnum);
	
	/****************** 장바구니 관련 메소드 *****************/
	/*public int addCart(CartVO cartVo);
	public int updateCartQty(CartVO cartVo);
	public List<CartVO> selectCartView(int midx);
	public int deleteCart(int cartNum);
	public int deleteCartByIdx(int midx, int tnum);*/
	
	/*
	*//***************** 주문 관련 메소드 *****************//*
	*//** 주문 개요 정보와 상품 정보를 insert 하는 메소드 *//*
	public String orderInsert(OrderVO ovo);
	
	*//** 수령자 정보를 insert *//*
	public int receiverInsert(OrderVO ovo);
	
	*//** 주문처리된 내역정보 가져오기 *//*
	List<OrderVO> getOrderDesc(String onum);
	
	*//** 특정 회원의 주문 목록 가져오기 *//*
	List<OrderVO> getUserOrderList(int midx_fk);
	*/

	/***************** 회원 관련 메소드 *****************/
	/** 검색이나 로그인시 */
	public MemberVO findMemberByEmail(String email1)
	throws NotMemberException;
	
	
	/** 회원가입 */
	public int insertMember(MemberVO member);
	public int emailCheck(String email);
	
	/** 로그인 처리 */
	public MemberVO isLoginOK(String email1, String pwd1) throws NotMemberException;

	/** 회원번호로 회원정보 가져오기 */
	public MemberVO selectByMidx(int midx);

}
