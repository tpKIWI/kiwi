package service.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import service.model.NoticeDAO;
import service.model.NoticeVO;
import service.model.PagingVO;

@Service
public class NoticeServiceImpl implements NoticeService {
	
	@Autowired
	private NoticeDAO noticeDao;

	public int insertNotice(NoticeVO notice) {
		
		return noticeDao.insertNotice(notice);
	}
	

	
	public List<NoticeVO> selectNoticeAll(PagingVO paging) {
		return noticeDao.selectNoticeAll(paging);
	}

	public List<NoticeVO> selectNoticeAll(Map<String, Integer> map) {
		
		return null;
	}

	public int getTotalCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	public NoticeVO selectNoticeByNidx(int nidx) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean updateReadnum(int nidx) {
		// TODO Auto-generated method stub
		return false;
	}

	public int deleteNotice(int nidx) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int updateNotice(NoticeVO notice) {
		// TODO Auto-generated method stub
		return 0;
	}



	public List<NoticeVO> findNotice(PagingVO paging) {
		// TODO Auto-generated method stub
		return null;
	}

	public int getTotalCount(PagingVO paging) {
		// TODO Auto-generated method stub
		return 0;
	}

}
