package service.model;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import javax.annotation.*;

@Repository(value="noticeDAOMyBatis")
public class NoticeDAOMyBatis extends SqlSessionDaoSupport
implements NoticeDAO {
	
	private final String NS="service.model.NoticeMapper";
	
	private static final Logger log
	=LoggerFactory.getLogger(NoticeDAOMyBatis.class);
	
	
	@Resource(name="sqlSessionFactory")
	@Override
	public void setSqlSessionFactory(SqlSessionFactory sqlSessionFactory) {
		super.setSqlSessionFactory(sqlSessionFactory);
	}

	public int insertNotice(NoticeVO notice) {
		return this.getSqlSession()
				.insert(NS+"insertNotice",notice);
	}
	
	public List<NoticeVO> selectNoticeAll(PagingVO paging) {
		return  this.getSqlSession()
				.selectList(NS+".listNoticePaging",paging);
	}

	public List<NoticeVO> selectNoticeAll(Map<String, Integer> map) {
		return getSqlSession()
				.selectList(NS+".listNotice",map);
	}

	public int getTotalCount() {
		// TODO Auto-generated method stub
		return 0;
	}

	public NoticeVO selectNoticeByNidx(int nidx) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean updateReadnum(int nidx) {
		// TODO Auto-generated method stub
		return false;
	}

	public int deleteNotice(int nidx) {
		// TODO Auto-generated method stub
		return 0;
	}

	public int updateNotice(NoticeVO notice) {
		// TODO Auto-generated method stub
		return 0;
	}


	public List<NoticeVO> findNotice(PagingVO paging) {
		// TODO Auto-generated method stub
		return null;
	}

	public int getTotalCount(PagingVO paging) {
		// TODO Auto-generated method stub
		return 0;
	}

}
