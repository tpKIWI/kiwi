package service.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class QnaController {

	@RequestMapping("/service/qnaListView.do")
	public void showIndex(){
		
	}
	
	@RequestMapping("/service/qnaInsertView.do")
	public void qnaInsertView(){
		
	}
	
	
	@RequestMapping("/service/qnaUpdateView.do")
	public void qnaUpdateView(){
		
	}
	
}
