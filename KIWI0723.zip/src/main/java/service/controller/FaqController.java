package service.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import service.controller.FaqController;
import common.util.CommonUtil;
import service.model.FaqDAO;
import service.model.FaqVO;
import service.service.FaqService;

@Controller
@RequestMapping("/service")
public class FaqController {

	@Autowired
	private FaqService faqService;
	
	@Autowired
	private CommonUtil util;
	
	private static final Logger log
	=LoggerFactory.getLogger(FaqController.class);
	
	@RequestMapping("/faqListView.do")
	public void showIndex(){

	}
	
	//@Autowried 객체를 주입할 때 사용
	//type(자료형)w으로 주입함
	//동일한 자료형의 객체가 여러 개 있을 떄는
	//@Qualifier 를 이용해 어떤 객체인지 지정한다.
	@Autowired	
	@Qualifier("faqDAOMyBatis")
	private FaqDAO faqDao;
	
	@RequestMapping(value="/faqInsertView.do",
			method=RequestMethod.POST)
	public String faqInsert(Model model,
			@ModelAttribute("faq") FaqVO faq){
				int n=this.faqService.faqInsert(faq);
				String msg=(n>0)?"글쓰기 성공":"글 쓰기 실패";
				String loc=(n>0)?"faqInsertView.do":"javascript:history.back()";	
				
				model.addAttribute("msg",msg);
				model.addAttribute("loc",loc);
				return "memo/message";
			}
	
}
