package common.service;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import talent.model.CategoryVO;
import talent.model.TalentDAO;
import talent.model.TalentVO;

@Service
public class KiwiServiceImpl implements KiwiService{
	
	@Resource(name="talentDAOMyBatis")
	private TalentDAO talentDao;
	
	public List<CategoryVO> getUpCategory() {
		return talentDao.getUpCategory();
	}

	public List<CategoryVO> getDwCategory(int upcode) {
		return talentDao.getDwCategory(upcode);
	}

	public List<TalentVO> selectByCategory(int dwcode) {
		return talentDao.selectByCategory(dwcode);
	}
	/*public List<TalentVO> selectByCategory(int upcode, int dwcode) {
		return talentDao.selectByCategory(upcode, dwcode);
	}*/
	
	public TalentVO selectByTnum(int tnum) {
		return talentDao.selectByTnum(tnum);
	}
}
