package common.service;

import java.util.List;
import talent.model.CategoryVO;
import talent.model.TalentVO;

public interface KiwiService {

	/****************** 재능 관련 메소드 ******************/
	/** 상위 분류 가져오기*/
	public List<CategoryVO> getUpCategory();
	
	/** 하위 분류 가져오기*/
	public List<CategoryVO> getDwCategory(int upcode);
	
	/** 분류별로 재능 목록 가져오기 */
	public List<TalentVO> selectByCategory(int dwcode);
	/*public List<TalentVO> selectByCategory(int upcode, int dwcode);*/
	
	/** 재능 번호로 특정 재능 가져오기 */
	public TalentVO selectByTnum(int tnum);
	
	
	/****************** 장바구니 관련 메소드 *****************/
	/*public int addCart(CartVO cartVo);
	public int updateCartQty(CartVO cartVo);
	public List<CartVO> selectCartView(int midx);
	public int deleteCart(int cartNum);
	public int deleteCartByIdx(int midx, int tnum);*/
	
	/*
	*//***************** 주문 관련 메소드 *****************//*
	*//** 주문 개요 정보와 상품 정보를 insert 하는 메소드 *//*
	public String orderInsert(OrderVO ovo);
	
	*//** 수령자 정보를 insert *//*
	public int receiverInsert(OrderVO ovo);
	
	*//** 주문처리된 내역정보 가져오기 *//*
	List<OrderVO> getOrderDesc(String onum);
	
	*//** 특정 회원의 주문 목록 가져오기 *//*
	List<OrderVO> getUserOrderList(int midx_fk);
	*/
}
