package talent.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import common.service.KiwiService;
import common.util.CommonUtil;
import talent.model.CategoryVO;
import talent.model.TalentVO;

@Controller
public class TalentController {

	@Autowired
	private KiwiService kiwi;
	
	@Autowired
	private CommonUtil util;
	
	/* 뷰이름이 반환되지 않으면 RequestMapping에 지정된 매핑 url에 .do를 빼고 .jsp를 붙여 찾아간다. WEB-INF/view/index.jsp와 같이. */
	@RequestMapping("/talent/talentList.do")
	public void talentList(Model model, 
			@RequestParam(defaultValue="0")int dwCode){
		List<TalentVO> tlist = kiwi.selectByCategory(dwCode);
		
		model.addAttribute("tlist", tlist);
	}
	
	@RequestMapping("/talent/talentCate.do")
	public String talentCategory(Model model,
			@RequestParam(defaultValue="0")int upCode,
			@RequestParam(defaultValue="0")int dwCode,
			@RequestParam(defaultValue="")String dwName){
		
		List<TalentVO> tlist=kiwi.selectByCategory(dwCode);
		List<CategoryVO> upCList=kiwi.getUpCategory();
		List<CategoryVO> dwCList=kiwi.getDwCategory(upCode);
		
		model.addAttribute("tlist", tlist);
		model.addAttribute("upCList", upCList);
		model.addAttribute("dwCList", dwCList);

		return "talent/talentListByCategory";
	}
	
	@RequestMapping("/talent/talentDetail.do")
	public void talentDeatil(){	// 반환타입 String
		
	}
	
	@RequestMapping("/talent/insertTalent.do")
	public void insertTalent(){
		
	}
	
	@RequestMapping("/talent/updateTalent.do")
	public void updateTalent(){
	}
	
	@RequestMapping("/talent/buyTalent.do")
	public void buyTalent(){

	}
	
}
