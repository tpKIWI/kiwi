package talent.model;

import java.util.List;

import talent.model.CategoryVO;
import talent.model.TalentVO;

public interface TalentDAO {
	/** 상위분류 가져오기*/
	public List<CategoryVO> getUpCategory();
	
	/** 하위분류  가져오기*/
	public List<CategoryVO> getDwCategory(int upcode);
		
	/** 분류에 해당하는 재능목록 가져오기*/
	public List<TalentVO> selectByCategory(int dwcode);
/*	public List<TalentVO> selectByCategory(int upcode, int dwcode);*/
	
	/** 재능번호로 특정 재능 가져오기*/
	public TalentVO selectByTnum(int tnum); 
}
