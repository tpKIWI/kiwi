package talent.model;

import java.io.Serializable;
import java.sql.Date;

public class TalentVO implements Serializable {

	private int		tnum;
	private String	tname;
	private int		tprice;
	private String	timg;
	private String	tspec;
	private String	tcontents;
	private String	asnrefund;
	private Date	tindate;
	private int		upcode;
	private int		dwcode;
	private int		midx;
	
	public TalentVO() {}

	public TalentVO(int tnum, String tname, int tprice, String timg, String tspec, String tcontents, String asnrefund,
			Date tindate, int upcode, int dwcode, int midx) {
		super();
		this.tnum = tnum;
		this.tname = tname;
		this.tprice = tprice;
		this.timg = timg;
		this.tspec = tspec;
		this.tcontents = tcontents;
		this.asnrefund = asnrefund;
		this.tindate = tindate;
		this.upcode = upcode;
		this.dwcode = dwcode;
		this.midx = midx;
	}

	public int getTnum() {return tnum;}
	public void setTnum(int tnum) {this.tnum = tnum;}

	public String getTname() {return tname;}
	public void setTname(String tname) {this.tname = tname;}

	public int getTprice() {return tprice;}
	public void setTprice(int tprice) {this.tprice = tprice;}

	public String getTimg() {return timg;}
	public void setTimg(String timg) {this.timg = timg;}

	public String getTspec() {return tspec;}
	public void setTspec(String tspec) {this.tspec = tspec;}

	public String getTcontents() {return tcontents;}
	public void setTcontents(String tcontents) {this.tcontents = tcontents;}

	public String getAsnrefund() {return asnrefund;}
	public void setAsnrefund(String asnrefund) {this.asnrefund = asnrefund;}

	public Date getTindate() {return tindate;}
	public void setTindate(Date tindate) {this.tindate = tindate;}

	public int getUpcode() {return upcode;}
	public void setUpcode(int upcode) {this.upcode = upcode;}

	public int getDwcode() {return dwcode;}
	public void setDwcode(int dwcode) {this.dwcode = dwcode;}

	public int getMidx() {return midx;}
	public void setMidx(int midx) {this.midx = midx;}

	@Override
	public String toString() {
		return "TalentVO [tnum=" + tnum + ", tname=" + tname + ", tprice=" + tprice + ", timg=" + timg + ", tspec="
				+ tspec + ", tcontents=" + tcontents + ", asnrefund=" + asnrefund + ", tindate=" + tindate + ", upcode="
				+ upcode + ", dwcode=" + dwcode + ", midx=" + midx + "]";
	}
	
}
