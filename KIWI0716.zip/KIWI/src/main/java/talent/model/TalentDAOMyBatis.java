package talent.model;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.mybatis.spring.support.SqlSessionDaoSupport;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

@Repository("talentDAOMyBatis")
public class TalentDAOMyBatis extends SqlSessionDaoSupport implements TalentDAO {

	private final String NS="talent.model.TalentMapper";
	private SqlSession ses;
	
	private static final Logger log
	=LoggerFactory.getLogger(TalentDAOMyBatis.class);
	
	@Resource(name="sqlSessionFactory")
	@Override
	public void setSqlSessionFactory(SqlSessionFactory sqlSessionFactory) {
		super.setSqlSessionFactory(sqlSessionFactory);
	}
	
	public List<CategoryVO> getUpCategory() {
		return this.getSqlSession().selectList(NS+".selectUpCategory");
	}

	public List<CategoryVO> getDwCategory(int upcode) {
		return this.getSqlSession().selectList(NS+".selectDwCategory", upcode);
	}

	public List<TalentVO> selectByCategory(int dwcode) {
		return getSqlSession().selectList(NS+".selectByCategory", dwcode);
	}

/*	public List<TalentVO> selectByCategory(int upcode, int dwcode) {
		ses = this.getSqlSession();
		Map<String, Integer> map = new HashMap<String, Integer>();
		map.put("upcode", upcode);
		map.put("dwcode", dwcode);
		
		List<TalentVO> arr
			= ses.selectList(NS+".selectByCategory", map);
		return arr;
	}*/
	
	public TalentVO selectByTnum(int tnum) {
		return getSqlSession().selectOne(NS+".selectByTnum", tnum);
	}

}
